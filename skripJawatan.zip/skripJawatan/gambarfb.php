<?php
$id = isset($_GET['id']) ? $_GET['id'] : '';
$xml=simplexml_load_file("jobxml.xml");
      //Set the Content Type
      header('Content-type:image/jpeg');

      // Create Image From Existing File
      $jpg_image = imagecreatefromjpeg('assets/img/01.jpg');

      // Allocate A Color For The Text
      $white = imagecolorallocate($jpg_image, 255, 255, 255);
	  $black = imagecolorallocate($jpg_image, 0, 0, 0);
	  $red = imagecolorallocate($jpg_image, 255, 0, 0);


      // Set Path to Font File
      $font = 'Roboto-Black.ttf';

	  $image_width = imagesx($jpg_image);  
	  $image_height = imagesy($jpg_image);
	  $font_size = 15;
	  $font_size2 = 14;
	  $font_size4 = 11;
	  $angle = 0;
	  include('code/config.php');
	  include('code/single.php');
$text = strtoupper(str_replace('-',' ',$title));
if(strlen($text)>54){
$font_size = 10.5;
}
$text2 = "SYARIKAT: ".strtoupper(str_replace('-',' ',$company));
if(strlen($text)>54){
$font_size2 = 12;
}
$tutup = $date4." ".$date5." ".date('Y');
$text3 = "TARIKH TUTUP: ".strtoupper($tutup);
$text4 = "SILA LAYARI ".strtoupper($webTitle)." UNTUK MAKLUMAT LANJUT";

// Get Bounding Box Size
$text_box = imagettfbbox($font_size,$angle,$font,$text);
$text_box2 = imagettfbbox($font_size2,$angle,$font,$text2);
$text_box3 = imagettfbbox($font_size,$angle,$font,$text3);
$text_box4 = imagettfbbox($font_size4,$angle,$font,$text4);


// Get your Text Width and Height
$text_width = $text_box[2]-$text_box[0];
$text_width2 = $text_box2[2]-$text_box2[0];
$text_width3 = $text_box3[2]-$text_box3[0];
$text_width4 = $text_box4[2]-$text_box4[0];

// Calculate coordinates of the text
$x = ($image_width/2) - ($text_width/2);
$x2 = ($image_width/2) - ($text_width2/2);
$x3 = ($image_width/2) - ($text_width3/2);
$x4 = ($image_width/2) - ($text_width4/2);

// Add some shadow to the text
//imagettftext($im, $font_size, 0, $x, $y+1, $grey, $font, $text);
// Add the text
imagettftext($jpg_image, $font_size, 0, $x, 65, $white, $font, $text);
imagettftext($jpg_image, $font_size2, 0, $x2, 230, $black, $font, $text2);
imagettftext($jpg_image, $font_size, 0, $x3, 260, $red, $font, $text3);
imagettftext($jpg_image, $font_size4, 0, $x4, 305, $white, $font, $text4);
      // Set Text to Be Printed On Image
      //$text = $_GET['t'];
	  //$text2 = $_GET['s'];

      // Print Text On Image
      //imagettftext($jpg_image, 10, 0, 6, 6, $white, $font_path, $text);
	  //imagettftext($jpg_image, 10, 0, 70, 60, $white, $font_path, $text2);

      // Send Image to Browser
      imagepng($jpg_image);

      // Clear Memory
      imagedestroy($jpg_image);
?>