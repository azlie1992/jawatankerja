<?php
include('code/config.php');
$source = "http://www.adhance.my/api/job/jobxml?id=".$adhanceID;
$outputfile = "jobxmll.xml";
$url = $source;//your url will come here
$fp = fopen ('jobxmll.xml', 'w+');
$ch = curl_init(str_replace(" ","%20",$url));
curl_setopt($ch, CURLOPT_TIMEOUT, 100);
curl_setopt($ch, CURLOPT_FILE, $fp); 
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_exec($ch); 
curl_close($ch);
fclose($fp);
sleep(10);
function extstr3($content,$start,$end){
  if($content && $start && $end) {
    $r = explode($start, $content);
    if (isset($r[1])){
        $r = explode($end, $r[1]);
        return $r[0];
    }
    return '';
  }
}
$xml = "jobxmll.xml";
$simpleXMLobject = file_get_contents($xml);
$first = '<?xml version="1.0" encoding="utf-8"?><adhance><job>';
$last = '</job></adhance>';
$read = $first.extstr3($simpleXMLobject,$first,$last).$last;
file_put_contents($xml, $read);
rename('jobxml.xml', 'oldjob.xml');
rename('jobxmll.xml','jobxml.xml');
?>