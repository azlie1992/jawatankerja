<?php
include('code/config.php');
include('code/xml.php');
if($num == 0){
include('code/career.php');
if($num == 0) {
include('code/indeed.php');
if($num == 0){
$notfound = 1;
}
}
}
if($id or $career or $indeed){
include('code/single.php'); 
}
if($indeed){ include('code/indeed/single.php');} 
elseif($career) { include('code/career/single.php'); }

include('template/phphtml/metaheader.php');
include('template/logo.php');
include('template/menu.html');
if(!$id AND !$career AND !$indeed AND $detCurUrl !== "/disclaimer.html" AND $detCurUrl !== "/privacy.html"){ 
include('template/phphtml/searchbox.php');
}

if($page<2 AND !$search AND !$location AND !$kateGori AND !$tYpe){
//include('template/phphtml/topbanner.php');
}
include('template/phphtml/ads.php');
if($id OR $career OR $indeed){
include('template/phphtml/contentsingle.php'); 
} else {
include('template/phphtml/content.php');
}
include('template/footer.php');
?>