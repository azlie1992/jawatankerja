<?php
include('code/config.php');
$app = $_GET['app'];
$count = strlen($app);
if($count == 6){
header("Location:https://www.maukerja.my/job/$app-?ref=kerjakosong");
} elseif ($count == 7){	
header("Location:https://www.maukerja.my/adhjobclick/$app-$adhanceID");
} elseif ($count == 16){
header("Location:http://www.indeed.com/rc/clk?jk=$app&atk=");
}
elseif ($count > 20){
header("Location:https://careerjet.com.my/job/$app.html?src=pj&affid=$careerjetID");
}
?>