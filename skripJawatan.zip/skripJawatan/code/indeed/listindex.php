        <!-- Job item -->
            <div class="col-xs-12">
              <a class="item-block" href="<?=$title;?>-<?=$jobkey;?>.html">
				<header>
								<div class="date"><?=$date1;?> <span><?=$date2;?></span></div>
                  <div class="hgroup">
                    <h4><?=$jobtitle;?></h4>
                    <h5><?=$company;?><span class="label label-success"><?=$city;?></span></h5>
                  </div>
                  <time ><?=waktuBaru($datE);?></time>
                </header>

                <div class="item-body">
                  <p class="small"><?=$snippet;?></p>
                </div>
              </a>
            </div>
            <!-- END Job item -->
