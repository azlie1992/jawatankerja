<?php
require_once('functions.php');
$page = isset($_GET['page']) ? $_GET['page'] : '';
$search = isset($_GET['query']) ? $_GET['query'] : '';
$cariJob = isset($_GET['job']) ? $_GET['job'] : '';
if($cariJob){
$search = $cariJob;
}
$search = str_replace('-',' ',$search);
$canonicalsearch = strtolower(str_replace(" ","-",$search));
$search = strtolower($search);
$search=ucwords($search);
$location = isset($_GET['loc']) ? $_GET['loc'] : '';
$location = str_replace('-',' ',$location);
$location = strtolower($location);
$location=ucwords($location);
$canonicallocation = strtolower(str_replace(" ","-",$location));
$kateGori = isset($_GET['cat']) ? $_GET['cat'] : '';
$tYpe = isset($_GET['type']) ? $_GET['type'] : '';
$id = isset($_GET['id']) ? $_GET['id'] : '';
$career = isset($_GET['career']) ? $_GET['career'] : '';
$indeed = isset($_GET['indeed']) ? $_GET['indeed'] : '';
$detCurUrl = $_SERVER['REQUEST_URI'];

if(!$page){
$page = 1;
}
libxml_use_internal_errors(true);
$xml=simplexml_load_file("jobxml.xml");
if($xml === false){
$xml=simplexml_load_file("oldjob.xml");
}
$num = $xml->job->count();

$start = 0;
$end = 10;
if($page > 1){
$start = ($page-1)*10;
$end = $start+10;
}

//negeri
$negeri = array("Johor","Kelantan","Kuala Lumpur","Labuan","Melaka","Negeri Sembilan","Pahang","Perak","Pulau Pinang","Putrajaya","Sabah","Sarawak","Selangor","Terengganu","Perlis","Kedah");

if (in_array($location, $negeri)) {
$lokasi = "region";
} else {
$lokasi = "city";
}

//type kerja
$arrayType = array( 'Full Time' => '1','Part Time' => '2','Full Time,Part Time' => '3','Internship' => '4');
if (in_array($tYpe, $arrayType)){
$typeSearch = array_search($tYpe, $arrayType);
}

//kategori
$arrayKategori = array( 'Call Center / BPO' => '1','Advertising / Marketing' => '2','Food & Beverage' => '3','Beauty / Fitness' => '4','Customer Service / Helpdesk' => '5','Retail / Merchandise' => '6','IT / Software' => '7','Admin / Clerical' => '8','Business / Mgmt Consulting' => '9','Engineering / Technical Consulting' => '10','IT / Hardware' => '11','Accounting / Tax Services' => '12','Manufacturing / Production' => '13','Arts / Design / Fashion' => '14','Sales / Biz Development' => '15','Heavy Industrial / Machinery' => '16','Exhibitions / Event Mgmt' => '17','Education / Training' => '18','HR Mgmt / Consulting' => '19','Entertainment / Media' => '20','Electrical & Electronics' => '21','Purchase / Supply Chain' => '22','Construction / Building' => '23','Environment / Health / Safety' => '24','Transportation / Logistics' => '25','Banking / Finance' => '26','Repair / Maintenance' => '27','Social Services / NGO' => '28','Automobile / Automotive' => '29','Insurance' => '30','Other industries' => '31','Agriculture / Poultry / Fisheries' => '32','Architecture / Interior Design' => '33','Travel / Tourism' => '34','Hotel / Hospitality' => '35','Property / Real Estate' => '36','Gems / Jewellery' => '37','Security / Law Enforcement' => '38','Apparel' => '39','Healthcare / Medical' => '40','R&D' => '41','Journalism' => '42','General & Wholesale Trading' => '43','Law / Legal' => '44','Telecommunication' => '45','Chemical / Fertilizers' => '46','Sports' => '47','BioTech / Pharmaceutical' => '48','Consumer Products / FMCG' => '49','Printing / Publishing' => '50','Medical / Healthcare / Beauty' => '51','Science & Technology' => '52');

if (in_array($kateGori, $arrayKategori)){
$kateGoriSearch = array_search($kateGori, $arrayKategori);
}

if(!$search AND !$location AND !$kateGori AND !$tYpe){
$res = $xml->xpath("//adhance/job[not(contains(languages,'Chinese')) and not(contains(company,'Pizza Hut Restaurants Sdn Bhd'))]");
$num = count($res);
} elseif ($search AND !$location AND !$kateGori AND !$tYpe) {
$res = $xml->xpath("//adhance/job[not(contains(languages, 'Chinese')) and contains(title, '$search') or contains(company, '$search')]");
$num = count($res);
} elseif (!$search AND $location AND !$kateGori AND !$tYpe) {
$res = $xml->xpath("//adhance/job[not(contains(languages, 'Chinese')) and contains($lokasi, '$location')]");
$num = count($res);
} elseif ($search AND $location AND !$kateGori AND !$tYpe) {
$res = $xml->xpath("//adhance/job[not(contains(languages, 'Chinese')) and contains(title, '$search') and contains($lokasi, '$location')]");
$num = count($res);
} elseif($kateGori AND !$search AND !$location AND !$tYpe){
$res = $xml->xpath("//adhance/job[not(contains(languages, 'Chinese')) and contains(category, '$kateGoriSearch')]");	
$num = count($res);
} elseif($tYpe AND !$kateGori AND !$search AND !$location){
$res = $xml->xpath("//adhance/job[not(contains(languages, 'Chinese')) and contract='$typeSearch']");
$num = count($res);
}
$bilMuka = ceil($num/10);
?>