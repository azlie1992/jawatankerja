<?php
if($id){
echo "$webUrl/$id.jpg";
} else {
echo "$webUrl/assets/img/02.jpg";	
}
?>