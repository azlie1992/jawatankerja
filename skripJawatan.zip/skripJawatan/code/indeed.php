<?php 
$ipaddclient = get_client_ip();
$userAgent = $_SERVER['HTTP_USER_AGENT'];

$xml = simplexml_load_file("http://api.indeed.com/ads/apisearch?publisher=966110671795794&q=$search&l=$location&sort=date&radius=&st=&jt=&start=$page&limit=10&fromage=&filter=&latlong=1&co=my&chnl=resultpage&userip=$ipaddclient&useragent=$userAgent&v=2");

$num = $xml->totalresults;
$totalIndeedResults = $xml->totalresults;  
?>