<?php
$searchplus = strtolower(str_replace(' ','+',$search));
$locplus = strtolower(str_replace(' ','+',$location));
if($indeed){
echo "$webUrl/$clearcano-$jobkey.html";
}
elseif($career){
echo "$webUrl/$clearcano-$career.html";
}
elseif($id){
echo "$webUrl/$canonicaltitle-$id.html";
}
elseif($detCurUrl == "/disclaimer.html"){
echo "$webUrl/disclaimer.html";
}
elseif($detCurUrl == "/privacy.html"){
echo "$webUrl/privacy.html";
}
elseif ($search AND !$location) {
echo "$webUrl/cari-$canonicalsearch";
if($page>1){echo "-$page";}
echo ".html";
} 
elseif (!$search AND $location) {
echo "$webUrl/lokasi-$canonicallocation";
if($page>1){echo "-$page";}
echo ".html";
} 
elseif ($search AND $location) {
echo "$webUrl/?query=$searchplus&loc=$locplus";
if($page>1){echo "&page=$page";}
} 
elseif($kateGori){
echo "$webUrl/?cat=$kateGori";
if($page>1){echo "&page=$page";}
} 
elseif($tYpe){
$typecano = $typeSearch;
$typecano = strtolower(str_replace(' ','-',$typecano));
echo "$webUrl/$typecano";
if($page>1){echo "-$page";}
echo ".html";
}  else{
echo $webUrl;
}
?>