<?php
if($id){
if($salary == "Undisclose"){
$gaji = "";	
} else {
$gaji = "gaji $salary";	
$gaji = str_replace('Per Month','sebulan',$gaji);
}
}
if($indeed){
echo "Jawatan $jobtitle di $lokasidetails. Kerja kosong $jobtitle dalam syarikat $company. Jawatan ini telah dipaparkan sejak $date. Sumber diambil dari $source";
}
elseif($career){
echo "Jawatan $title di $region. Kerja kosong $title dalam syarikat $company. Jawatan ini telah dipaparkan sejak $date4 $date5 ".date('Y');
}
elseif($id){
echo "Jawatan $cleartitle di $region dengan $gaji. Kerja $contract dalam syarikat $clearcompany. Tarikh tutup permohonan adalah $date4 $date5 ".date('Y').". Jawatan ini dalam kategori $category.";
}
elseif($detCurUrl == "/disclaimer.html"){
echo "Disclaimer - ".$webTitle;
}
elseif($detCurUrl == "/privacy.html"){
echo "Privacy - ".$webTitle;
}
elseif ($search AND !$location) {
echo "Hasil carian kerja $search. Terdapat $num hasil carian kerja $search. Sila klik untuk maklumat lanjut.";
} 
elseif (!$search AND $location) {
echo "Hasil carian kerja di $location. Terdapat $num hasil carian kerja di $location. Sila klik untuk maklumat lanjut.";
} 
elseif ($search AND $location) {
echo "Hasil carian kerja $search di $location. Terdapat $num hasil carian kerja $search di $location. Sila klik untuk maklumat penuh.";
} 
elseif($kateGori){
echo "Hasil carian kerja menggunakan kategori $kateGoriSearch. Terdapat $num hasil carian kerja $kateGoriSearch. Sila klik untuk maklumat penuh.";
} 
elseif($tYpe){
echo "Hasil carian kerja mengikut jenis kerja $typeSearch. Terdapat $num hasil carian kerja $typeSearch. Sila klik untuk maklumat penuh.";
}
else{
echo $webDesc; if($page>1){ echo " page ".$page;}
}
?>