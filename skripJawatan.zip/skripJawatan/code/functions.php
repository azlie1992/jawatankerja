<?php 

function get_client_ip() {
$ipaddress = '';
if (getenv('HTTP_CLIENT_IP'))
$ipaddress = getenv('HTTP_CLIENT_IP');
else if(getenv('HTTP_X_FORWARDED_FOR'))
$ipaddress = getenv('HTTP_X_FORWARDED_FOR');
else if(getenv('HTTP_X_FORWARDED'))
$ipaddress = getenv('HTTP_X_FORWARDED');
else if(getenv('HTTP_FORWARDED_FOR'))
$ipaddress = getenv('HTTP_FORWARDED_FOR');
else if(getenv('HTTP_FORWARDED'))
$ipaddress = getenv('HTTP_FORWARDED');
else if(getenv('REMOTE_ADDR'))
$ipaddress = getenv('REMOTE_ADDR');
else
$ipaddress = 'UNKNOWN';
return $ipaddress;
}

if (!function_exists('waktuBaru')){

function waktuBaru($time_ago)
{
    $time_ago = strtotime($time_ago);
    $cur_time   = time();
    $time_elapsed   = $cur_time - $time_ago;
	 
    if ($time_elapsed < 1)
    {
        return '0 saat';
    }

    $a = array( 365 * 24 * 60 * 60  =>  'tahun',
                 30 * 24 * 60 * 60  =>  'bulan',
                      24 * 60 * 60  =>  'hari',
                           60 * 60  =>  'jam',
                                60  =>  'minit',
                                 1  =>  'saat'
                );
    $a_plural = array( 'tahun'   => 'tahun',
                       'bulan'  => 'bulan',
                       'hari'    => 'hari',
                       'jam'   => 'jam',
                       'minit' => 'minit',
                       'saat' => 'saat'
                );

    foreach ($a as $secs => $str)
    {
        $d = $time_elapsed / $secs;
        if ($d >= 1)
        {
            $r = round($d);
            return $r . ' ' . ($r > 1 ? $a_plural[$str] : $str) . ' lalu';
        }
    }
}
}
 ?>