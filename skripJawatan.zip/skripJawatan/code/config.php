<?php
// tajuk pada halaman utama
$webName = "Jawatan.Org - Portal Jawatan Kosong Kerajaan & Swasta Online ".date('Y');

//description halaman utama
$webDesc = "Lamanweb jawatan kosong kerajaan dan swasta terkini ".date('Y').". Beribu kerja kosong terbaru dikemaskini setiap hari. jobs vacancy in Malaysia.";

// url penuh termasuk http:// or https:// 
// jangan letakkan tanda slash "/" pada hujung url
$webUrl = "https://www.jawatan.org";

// tajuk ini digunakan dalam page seperti disclaimer, privacy policy dan juga dibahagian bawah lamanweb anda
$webTitle = "Yourwebsite.com";

// fb application id (gunakan fungsi ini sekiranya share ke facebook tidak berfungsi dengan baik)
// buat aplikasi di https://developers.facebook.com/apps/
$fbID = "824362524392385";

// fb page anda sekiranya ada. digunakan dalam halaman disclaimer & privacy policy, sidebar
$fbPage = "https://www.facebook.com/Kerja-Kosong-773642656116923/";

// masuk ke adhance panel anda http://www.adhance.my/xmlfeed (sila baca readme untuk daftar affiliate maukerja)
// right klik, dan copy link download xml tersebut.
// letakkan id sahaja, contoh gunakan e768e daripada link yang copy tadi http://www.adhance.my/api/job/jobxml?id=e768e
// id xml feed ini tidak sama dengan id affiliate anda.
$adhanceID = "e768e";

// careerjet affiliate id boleh didapati di panel utama. (sila baca readme untuk daftar affiliate careerjet)
$careerjetID = "7772ee2631b7218ce4b0db2037dd28d8";

// tambah lamanweb anda dalam google analytics, dapatkan number ID dalam panel analytics anda seperti contoh dibawah.
$analyticsId = "UA-16499359-13";

// share button melalui addthis.com, create share button (inline) dalam panel dan publish, letakkan username addthis anda dibawah ini.
$addThis = "far3dz";

// descriptions pada bahagian bawah lamanweb.
$footerDesc = "Portal carian jawatan & kerja kosong terpantas di Malaysia. Jawatan Kosong Kerajaan & Swasta Terkini ".date('Y');
?>