<?php
if($indeed){
echo "jawatan kosong $jobtitle, kerja di $lokasidetails, jawatan $jobtitle di $lokasidetails, kerja kosong $company";
}
elseif($career) {
echo "jawatan kosong $title, kerja di $region, jawatan $title di $region, kerja kosong $company";
}
elseif($id){
echo "jawatan kosong $cleartitle, kerja di $region, jawatan $cleartitle di $region, kerja kosong $clearcompany";
}
elseif ($search AND !$location) {
echo "jawatan kosong $search, kerja $search, kerja kosong $search, jawatan $search";
} 
elseif (!$search AND $location) {
echo "kerja di $location, jawatan kosong di $location, kerja kosong di $location, jawatan di $location";
} 
elseif ($search AND $location) {
echo "kerja $search di $location, jawatan kosong $search di $location, kerja kosong $search di $location, jawatan $search di $location";
} 
elseif($kateGori){
echo "kerja $kateGoriSearch, jawatan kosong $kateGoriSearch, kerja kosong $kateGoriSearch, jawatan $kateGoriSearch";
} 
elseif($tYpe){
echo "kerja kosong, jawatan, full time, part time, praktikal, internship";
} 
else {
echo "jawatan kosong, kerja kosong, web kerja kosong, interview, praktikal";
} 
?>