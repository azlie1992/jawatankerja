<?php
if($indeed){
echo $jobtitle." di ".$lokasidetails." - ".$webTitle;
}
elseif($career) {
echo $title." di ".$region." - ".$webTitle;
}
elseif($id){
echo $cleartitle." di ".$region." - ".$webTitle;
}
elseif($detCurUrl == "/disclaimer.html"){
echo "Disclaimer - ".$webTitle;
}
elseif($detCurUrl == "/privacy.html"){
echo "Privacy - ".$webTitle;
}
elseif ($search AND !$location) {
echo "Carian jawatan ".$search." - ".$webTitle; if($page>1){ echo " page ".$page;}
} 
elseif (!$search AND $location) {
echo "Jawatan Kosong di ".$location." - ".$webTitle; if($page>1){ echo " page ".$page;}
} 
elseif ($search AND $location) {
echo "Jawatan Kosong ".$search." di ".$location." - ".$webTitle; if($page>1){ echo " page ".$page;}
} 
elseif($kateGori){
echo "Jawatan dalam ".$kateGoriSearch." - ".$webTitle; if($page>1){ echo " page ".$page;}
} 
elseif($tYpe){
echo "Jawatan ".$typeSearch." - ".$webTitle; if($page>1){ echo " page ".$page;}
} 
else {
echo $webName; if($page>1){ echo " page ".$page;}
} 
?>