<?php
$detCurUrl = $_SERVER['REQUEST_URI'];
$resId = $xml->xpath("//adhance/job[not(contains(languages, 'Chinese')) and contains(id, '$id')]");
foreach($resId as $item) {
$title = $item->title;
$cleartitle = trim(preg_replace('/ +/', ' ', preg_replace('/[^A-Za-z0-9 ]/', ' ', urldecode(html_entity_decode(strip_tags($title))))));
$canonicaltitle = strtolower(str_replace(" ","-",$cleartitle));
$pubDate = $item->pubdate; 
$date = explode(' ',$pubDate);
$date = explode('/',$date[1]);
$date1 = $date[0];
$date2 = $date[1];
$dateObj   = DateTime::createFromFormat('!m', $date2);
$date2 = $dateObj->format('M'); 
$category = (string) $item->category;
$company = (string) $item->company;
$clearcompany = trim(preg_replace('/ +/', ' ', preg_replace('/[^A-Za-z0-9 ]/', ' ', urldecode(html_entity_decode(strip_tags($company))))));
$companylink = strtolower(str_replace(' ','-',$clearcompany));
$salary = (string) $item->salary;
$content = (string) $item->content;
$content = str_replace('Benifits','Benefits',$content);
$expiryDate = $item->expirydate;
$expDate = explode(' ',$expiryDate);
$expDate = explode('/',$expDate[1]);
$date4 = $expDate[0];
$date5 = $expDate[1];
$dateObj2   = DateTime::createFromFormat('!m', $date5);
$date5 = $dateObj2->format('M'); 
$city = $item->city;
$clearcity = trim(preg_replace('/ +/', ' ', preg_replace('/[^A-Za-z0-9 ]/', ' ', urldecode(html_entity_decode(strip_tags($city))))));
$citylink = strtolower(str_replace(' ','-',$clearcity));
$region = $item->region; 
$clearregion = trim(preg_replace('/ +/', ' ', preg_replace('/[^A-Za-z0-9 ]/', ' ', urldecode(html_entity_decode(strip_tags($region))))));
$regionlink = strtolower(str_replace(' ','-',$clearregion));
$contract = $item->contract; 
$category = $item->category;
$studies = $item->studies;
$url = $item->url;
$codeJob = explode('/',$url);
$codeJob = end($codeJob);
$codeJob = explode('-',$codeJob);
$codeJob = $codeJob[0];
//$url = explode('-',$url);
//$url = $url[0]."-".$adhanceID;
}	
?>