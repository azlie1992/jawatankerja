<?php 
require_once('code/career/Careerjet_API.php');
$api = new Careerjet_API('en_MY');
$result = $api->search(array( 'keywords' => "$search",
                              'location' => "$location",
							  'affid' => "$careerjetID",
							  'pagesize' => '10',
                              'page' => $page
                          )
                       );
$num = $result->hits;	
$totaljetResults = $result->hits;				   
?>