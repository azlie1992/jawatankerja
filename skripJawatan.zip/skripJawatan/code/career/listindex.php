        <!-- Job item -->
            <div class="col-xs-12">
              <a class="item-block" href="<?=$canonicaltitle;?>-<?=$url;?>.html">
                <header>
				<div class="date"><?=$date1;?> <span><?=$date2;?></span></div>
                  <div class="hgroup">
                    <h4><?=$title;?></h4>
                    <h5><?=$company;?><span class="label label-success"><?=$locations;?></span></h5>
                  </div>
                  <time ><?=waktuBaru($datE);?></time>
                </header>

                <div class="item-body hidden-xs">
                  <p class="small"><?=$desc;?></p>
                </div>
              </a>
            </div>
            <!-- END Job item -->
