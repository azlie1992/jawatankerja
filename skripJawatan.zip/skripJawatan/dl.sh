#!/bin/bash
wget -O /home/jawatan/public_html/jobxml2.xml http://www.adhance.my/api/job/jobxml?id=e768e
curl https://www.jawatan.org/dl2.php