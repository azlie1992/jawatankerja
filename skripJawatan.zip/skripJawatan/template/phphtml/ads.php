<?php
// tak perlu copy line <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
// ads atas sekali sebelum job list
// gunakan in-feed ads
$adsTop = '
<ins class="adsbygoogle"
     style="display:block"
     data-ad-format="fluid"
     data-ad-layout-key="-gu-u+21-3t+6h"
     data-ad-client="ca-pub-3336434415284237"
     data-ad-slot="9301699906"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>';
// ads bawah sekali selepas job list
// gunakan in-feed ads

$adsBottom = '
<ins class="adsbygoogle"
     style="display:block"
     data-ad-format="fluid"
     data-ad-layout-key="-gu-u+21-3t+6h"
     data-ad-client="ca-pub-3336434415284237"
     data-ad-slot="9301699906"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>';

// ads diantara job list
// gunakan in-feed ads
	
$adsCenter = '
<ins class="adsbygoogle"
     style="display:block"
     data-ad-format="fluid"
     data-ad-layout-key="-gu-u+21-3t+6h"
     data-ad-client="ca-pub-3336434415284237"
     data-ad-slot="9301699906"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>';

// ads dalam single page sidebar
// guna text & display ads responsive		
$adsSidebar = '
<!-- Jawatan Responsive MainPage -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-3336434415284237"
     data-ad-slot="1671058295"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>';

// ads bawah tajuk kerja dalam single page - 2 ads
// ads 1 guna text & display responsive
// ads 2 guna text & display (link ads responsive)
$belowTitle = '
<!-- Jawatan AdLink -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-3336434415284237"
     data-ad-slot="1671058295"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-3336434415284237"
     data-ad-slot="8322638650"
     data-ad-format="link"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>';

// ads di atas apply button
// ads guna text & display ( link ads 200x90)
$adsAboveApply = '
<!-- Jawatan Adlink Small -->
<ins class="adsbygoogle"
     style="display:inline-block;width:200px;height:90px"
     data-ad-client="ca-pub-3336434415284237"
     data-ad-slot="5375065202"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>';
?>