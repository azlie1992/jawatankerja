    <!-- Site header -->
    <header class="site-header size-lg text-center" style="background-image: url(assets/img/bg-banner1.jpg)">
      <div class="container">
        <div class="col-xs-12">
          <?php include ('template/phphtml/ayatmula.php');?>
		  <?php if($page<2 AND !$search AND !$location AND !$kateGori AND !$tYpe){ ?>
          <form class="header-job-search" action="index.php">
            <div class="input-keyword">
              <input type="text" class="form-control" name="query" placeholder="Job title, skills, or company">
            </div>

            <div class="input-location">
              <input type="text" class="form-control" name="loc" placeholder="City, state">
            </div>

            <div class="btn-search">
              <button class="btn btn-primary" type="submit">Find jobs</button>
            </div>
          </form>
		  <?php } ?>
        </div>

      </div>
    </header>
    <!-- END Site header -->