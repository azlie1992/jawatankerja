<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php include ('code/metadescription.php');?>">
    <meta name="keywords" content="<?php include('code/metakeywords.php');?>">

    <title><?php include ('code/metatitle.php');?></title>

    <!-- Styles -->
    <link href="assets/css/app.min.css" rel="stylesheet">
    <link href="assets/css/custom.css" rel="stylesheet">

    <!-- Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Raleway:100,300,400,500,600,800%7COpen+Sans:300,400,500,600,700,800%7CMontserrat:400,700' rel='stylesheet' type='text/css'>

    <!-- Favicons -->
    <link rel="apple-touch-icon" href="/apple-touch-icon.png">
    <link rel="icon" href="assets/img/favicon.ico">
	<link rel="canonical" href="<?php include('code/canonical.php');?>" />
	<meta property="og:title" content="<?php include('code/metatitle.php');?>" />
	<meta property="og:type" content="<?php if($id or $career or $indeed){echo "article";}else{echo"website";}?>" />
	<meta property="og:url" content="<?php include('code/canonical.php');?>" />
	<meta property="og:image" content="<?php include('code/fbimage.php');?>" />
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
  </head>

  <body class="nav-on-header smart-nav">
  
    <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.6&appId=<?=$fbID;?>";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

    <!-- Navigation bar -->
    <nav class="navbar">
      <div class="container">