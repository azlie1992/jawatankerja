        <!-- Page header -->
    <header class="page-header bg-img size-lg" style="background-image: url(assets/img/bg-banner2.jpg)">
      <div class="panel panel-default container">
        <div class="header-detail">
          <img class="logo" src="assets/img/logo.png" alt="">
          <div class="hgroup">
            <h1>Privacy Policy</h1>
            <h3><a href="#"><?=$webTitle;?></a></h3>
          </div>
          <time datetime="2017-10-14 20:00">14 October 2017</time>
          <hr>
          <p class="lead">If you require any more information or have any questions about our privacy policy, please feel free to contact us by Facebook Page . At <?=$webTitle;?>, the privacy of our visitors is of extreme importance to us. This privacy policy document outlines the types of personal information is received and collected by <?=$webTitle;?> and how it is used.
</p>

          <div class="button-group">
            <ul class="social-icons">
              <li class="title">Share on</li>
              <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a class="google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
              <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
            </ul>

            <div class="action-buttons">
              <a class="btn btn-primary" href="<?=$fbPage;?>" target="_blank">Contact Us On Facebook</a>
            </div>
          </div>

        </div>
      </div>
    </header>
    <!-- END Page header -->
	
	<!-- Main container -->
    <main>

      <!-- Job detail -->
      <section>
        <div class="container">

          <br>
          <h4>PRIVACY POLICY FOR WWW.<?=strtoupper($webTitle);?>:</h4>
          <p>Like many other Web sites, <?=$webTitle;?> makes use of log files. The information inside the log files includes internet protocol ( IP ) addresses, type of browser, Internet Service Provider ( ISP ), date/time stamp, referring/exit pages, and number of clicks to analyze trends, administer the site, track user's movement around the site, and gather demographic information. IP addresses, and other such information are not linked to any information that is personally identifiable.</p>

          <br>
          <h4>DoubleClick DART Cookie</h4>
          <p>.:: Google, as a third party vendor, uses cookies to serve ads on <?=$webTitle;?>.
.:: Google's use of the DART cookie enables it to serve ads to users based on their visit to <?=$webTitle;?> and other sites on the Internet.
.:: Users may opt out of the use of the DART cookie by visiting the Google ad and content network privacy policy at the following URL - http://www.google.com/privacy_ads.html</p>

<p>Some of our advertising partners may use cookies and web beacons on our site. Our advertising partners include Innity, Indeed & Careerjet</p>

<p>These third-party ad servers or ad networks use technology to the advertisements and links that appear on <?=$webTitle;?> send directly to your browsers. They automatically receive your IP address when this occurs. Other technologies ( such as cookies, JavaScript, or Web Beacons ) may also be used by the third-party ad networks to measure the effectiveness of their advertisements and / or to personalize the advertising content that you see. </p>

<p><?=$webTitle;?> has no access to or control over these cookies that are used by third-party advertisers. </p>

<p>You should consult the respective privacy policies of these third-party ad servers for more detailed information on their practices as well as for instructions about how to opt-out of certain practices. <?=$webTitle;?>'s privacy policy does not apply to, and we cannot control the activities of, such other advertisers or web sites. </p>

<p>If you wish to disable cookies, you may do so through your individual browser options. More detailed information about cookie management with specific web browsers can be found at the browsers' respective websites.</p>

        </div>
      </section>
      <!-- END Job detail -->

    </main>
    <!-- END Main container -->