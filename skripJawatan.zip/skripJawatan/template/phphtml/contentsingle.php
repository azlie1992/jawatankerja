    <header class="page-header bg-img size-lg" style="background-image: url(assets/img/bg-banner2.jpg)">
      <div class="container no-shadow">
	  <?php if($indeed){ include('code/indeed/details.php');} elseif($career) { include('code/career/details.php'); } else {?>
        <h1 class="text-center"><?=$title;?></h1>
        <p class="lead text-center"><a href="jawatan-kosong-<?=$companylink;?>.html"><?=$company;?></a> <br> <?=$date1." ".$date2;?> <?=date('Y');?></p>
      </div>
    </header>
	
	<!-- Main container -->
    <main class="container blog-page">
<?php
$kateGoriSearch = array_search($arrayKategori["$category"], $arrayKategori);
?>
      <div class="row">
<ol class="breadcrumb">
  <li class="breadcrumb-item"><a href="<?=$webUrl;?>">Home</a></li>
  <li class="breadcrumb-item"><a href="index.php?cat=<?=$arrayKategori["$category"];?>"><?=$kateGoriSearch;?></a></li>
  <li class="breadcrumb-item active"><?=$title;?></li>
</ol>
        <div class="item-block col-md-8 col-lg-9">

            <header>
			<div class="date"><?=$date1;?> <span><?=$date2;?></span></div>
<h4><?=$title;?></h4>
<h5><?=$company;?></h5>
</header><div class="item-body details">
<p class="small">Advertisements</p><?=$belowTitle;?>
              <p>
			  <b>Gaji: </b> <ul><li><?=$salary;?></li></ul>
			  <?=$content;?>
			  <b>Kelayakan: </b><ul><li><?=$studies;?></li></ul>
			  <b>Lokasi: </b> <ul><li><a href="lokasi-<?=$citylink;?>.html"><?=$city;?></a> , <a href="lokasi-<?=$regionlink;?>.html"><?=$region;?></a><br></li></ul>
			  <b>Tarikh Tutup: <ul><li></b> <?=$date4." ".$date5." ".date('Y');?><br></li></ul>
			  </p>
			  <p class="small">Advertisements</p><?=$adsAboveApply;?>
			  <div class="action-buttons"><br>
              <a class="btn btn-danger btn-outline btn-sm" href="mohon-<?=$codeJob;?>.html" title="apply job <?=$title;?>" target="_blank">Apply Job</a>
      </div>
            </div>

	  <?php } ?>

	  <div class="addthis_inline_share_toolbox"></div>
	  <br>
<div class="clearfix">
<div class="fb-comments" data-href="<?=$webUrl;?><?=$detCurUrl;?>" data-numposts="5" data-width="100%"></div>
</div>
        </div>
        
<?php include('template/phphtml/sidebar.php');?>      

      </div>

    </main>
    <!-- END Main container -->