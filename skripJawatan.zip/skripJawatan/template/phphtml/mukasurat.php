<?php 
if(!$search AND !$location AND !$kateGori AND !$tYpe){
$mukasurat = "index.php?page=";	
} elseif ($search AND !$location AND !$kateGori AND !$tYpe) {
$mukasurat = "index.php?query=$search&page=";	
} elseif (!$search AND $location AND !$kateGori AND !$tYpe) {
$mukasurat = "index.php?loc=$location&page=";
} elseif ($search AND $location AND !$kateGori AND !$tYpe) {
$mukasurat = "index.php?query=$search&loc=$location&page=";	
} elseif($kateGori AND !$search AND !$location AND !$tYpe){
$mukasurat = "index.php?cat=$kateGori&page=";	
} elseif($tYpe AND !$kateGori AND !$search AND !$location){
$mukasurat = "index.php?type=$tYpe&page=";	
} ?>
		
		<div class="container">
			<div class="col-xs-12">
				<nav class="text-center">
				  <ul class="pagination">
<?php
if ($page >= 1 && $page < 3) { 							
if ($page != 1) { ?><li><a href="<?=$mukasurat;?><?=$page-1;?>" class="fa fa-angle-left"></a></li>							<?php }							
							if ($page == 2) {?>							<li><a href="<?=$mukasurat;?>1">1</a></li>							<?php }?>							<li class="active"><a href="#"><?=$page;?></a></li>							<?php }
if ($page > 2) {?>							<li><a href="<?=$mukasurat;?><?=$page-1;?>" class="fa fa-angle-left"></a></li>							<li><a href="<?=$mukasurat;?>1">1</a></li>							<li><a>...</a></li>							<li class="active"><a href="#"><?=$page?></a></li>							<?php }
if(!$page){$pages = 1;} else{$pages = @$_GET['page'];}
while( $pages <= $page+2 AND $pages < $bilMuka ){								if($pages > $page){								echo "<li><a href='$mukasurat$pages'>$pages</a></li>";								}					$pages++;					}

if ( $page != $bilMuka){ ?>							<li><a href="<?=$mukasurat;?><?=$page+1;?>" class="fa fa-angle-right"></a></li>							<?php } ?>
				  </ul>
				</nav>
			</div>
			<div class="clearfix"> </div>
		</div>