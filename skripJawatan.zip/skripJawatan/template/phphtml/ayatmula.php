<?php
if(!$search AND !$location AND !$kateGori AND !$tYpe AND !$id){
	
echo '<h2>Terdapat <mark>'.$num.'</mark> kekosongan jawatan pada <mark>hari ini</mark></h2>
      <h5 class="font-alt">Cari kerja yang anda inginkan sekarang</h5>';
	  
} elseif ($search AND !$location AND !$kateGori AND !$tYpe AND !$id) {
	
echo '<h2>Terdapat <mark>'.$num.'</mark> jawatan <mark>'.$search.'</mark></h2>
      <h5 class="font-alt">Lihat kerja yang anda inginkan sekarang</h5>';
	  
} elseif (!$search AND $location AND !$kateGori AND !$tYpe AND !$id) {
	
echo '<h2>Terdapat <mark>'.$num.'</mark> kerja kosong di <mark>'.$location.'</mark></h2>
      <h5 class="font-alt">Lihat kerja yang anda inginkan sekarang</h5>';
	  
} elseif ($search AND $location AND !$kateGori AND !$tYpe AND !$id) {
	
echo '<h2>Terdapat <mark>'.$num.'</mark> hasil carian <mark>'.$search.'</mark> di <mark>'.$location.'</mark></h2>
      <h5 class="font-alt">Lihat kerja yang anda inginkan sekarang</h5>';
	  
} elseif($kateGori AND !$search AND !$location AND !$tYpe AND !$id){
	
echo '<h2>Terdapat <mark>'.$num.'</mark> jawatan dalam kategori <mark>'.$kateGoriSearch.'</mark></h2>
      <h5 class="font-alt">Lihat kerja yang anda inginkan sekarang</h5>';
	  
} elseif($tYpe AND !$kateGori AND !$search AND !$location AND !$id){
	
echo '<h2>Terdapat <mark>'.$num.'</mark> jawatan <mark>'.$typeSearch.'</mark></h2>
      <h5 class="font-alt">Lihat kerja yang anda inginkan sekarang</h5>';
	  
}
?>