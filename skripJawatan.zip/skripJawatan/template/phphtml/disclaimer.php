        <!-- Page header -->
    <header class="page-header bg-img size-lg" style="background-image: url(assets/img/bg-banner2.jpg)">
      <div class="panel panel-default container">
        <div class="header-detail">
          <img class="logo" src="assets/img/logo.png" alt="">
          <div class="hgroup">
            <h1>Disclaimer</h1>
            <h3><a href="#"><?=$webTitle;?></a></h3>
          </div>
          <time datetime="2017-10-14 20:00">14 October 2017</time>
          <hr>
          <p class="lead">If you require any more information or have any questions about our site's disclaimer,<br> please feel free to contact us by Facebook Page.

</p>

          <div class="button-group">
            <ul class="social-icons">
              <li class="title">Share on</li>
              <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a class="google-plus" href="#"><i class="fa fa-google-plus"></i></a></li>
              <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
            </ul>

            <div class="action-buttons">
              <a class="btn btn-primary" href="<?=$fbPage;?>" target="_blank">Contact Us On Facebook</a>
            </div>
          </div>

        </div>
      </div>
    </header>
    <!-- END Page header -->
	
	<!-- Main container -->
    <main>

      <!-- Job detail -->
      <section>
        <div class="container">

          <br>
          <h4>DISCLAIMERS FOR WWW.<?=$webTitle;?>:</h4>
          <p>All the information on this website is published in good faith and for general information purpose only. www.<?=$webTitle;?> does not make any warranties about the completeness, reliability and accuracy of this information. Any action you take upon the information you find on this website (www.<?=$webTitle;?>), is strictly at your own risk. www.<?=$webTitle;?> will not be liable for any losses and/or damages in connection with the use of our website.</p>
		  <p>From our website, you can visit other websites by following hyperlinks to such external sites. While we strive to provide only quality links to useful and ethical websites, we have no control over the content and nature of these sites. These links to other websites do not imply a recommendation for all the content found on these sites. Site owners and content may change without notice and may occur before we have the opportunity to remove a link which may have gone 'bad'.</p>
          <p>Please be also aware that when you leave our website, other sites may have different privacy policies and terms which are beyond our control. Please be sure to check the Privacy Policies of these sites as well as their "Terms of Service" before engaging in any business or uploading any information.</p>

          <br>
          <h4>CONSENT</h4>
          <p>By using our website, you hereby consent to our disclaimer and agree to its terms.</p>

          <br>
          <h4>UPDATE</h4>
          <p>This site disclaimer was last updated on: Saturday, October 14th, 2017
· Should we update, amend or make any changes to this document, those changes will be prominently posted here.</p>

        </div>
      </section>
      <!-- END Job detail -->

    </main>
    <!-- END Main container -->