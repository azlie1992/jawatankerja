<?php 
if($detCurUrl == "/disclaimer.html"){ include('template/phphtml/disclaimer.php');}
elseif($detCurUrl == "/privacy.html"){ include('template/phphtml/privacy.php'); } else { ?>
	<!-- Main container -->
    <main>



      <!-- Recent jobs -->
      <section>
        <div class="container">
		<?php if(!$search AND !$location AND !$kateGori AND !$tYpe){ ?>
          <header class="section-header">
            <h2>Kerja Kosong Terkini (<?=$num;?> Jawatan) </h2>
          </header>
		<?php } ?>
          <div class="row item-blocks-condensed">
	  <div class="addthis_inline_share_toolbox text-center"></div>
<?php
echo '<div class="col-xs-12 text-center"><p class="small"></p>';
echo $adsTop;
echo "</div>";
?>
<?php if(@$totaljetResults != 0) { include('code/career/index.php'); } elseif(@$totalIndeedResults != 0){ include('code/indeed/index.php'); } else { include('template/phphtml/listindex.php'); }?>
<?php if(@$notfound){?>

<header class="site-header size-lg text-center">
      <div class="container">
        <div class="col-xs-12">
<div class="alert alert-danger" role="alert">
            <strong>Maaf!</strong> Carian anda tidak ditemui. Sila gunakan perkataan <strong>English</strong> dalam kotak carian. Anda boleh memasukkan nama jawatan, nama syarikat <strong>ATAU</strong> lokasi(negeri, bandar) dalam ruang yang disediakan di bawah.
</div>          <form class="header-job-search" action="index.php">
            <div class="input-keyword">
              <input type="text" class="form-control" name="query" placeholder="Job title, skills, or company">
            </div>

            <div class="input-location">
              <input type="text" class="form-control" name="loc" placeholder="City, state">
            </div>

            <div class="btn-search">
              <button class="btn btn-primary" type="submit">Find jobs</button>
            </div>
          </form>
        </div>

      </div>
    </header>
<?php }?>
		  <?php
		  echo '<div class="col-xs-12 text-center"><p class="small"></p>';
echo $adsBottom;
echo "</div>";
		  ?>
          </div>
          <p class="text-center"><?php include('template/phphtml/mukasurat.php');?></p>
		  <?php if ($location) { include ('template/phphtml/dalamnegeri.php');}?>

        </div>

      </section>
      <!-- END Recent jobs -->

    </main>
    <!-- END Main container -->
<?php } ?>