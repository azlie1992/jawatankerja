		<div class="col-md-4 col-lg-3">
<br>

<div class="widget">
            <h6 class="widget-title">Sponsored Links</h6>
            <div class="widget-body">
            <?=$adsSidebar;?>
            </div>
          </div>
		  
          <div class="widget">
            <h6 class="widget-title">Cari Kerja Lagi</h6>
            <div class="widget-body">
              <form action="index.php">
                <input class="form-control" type="text" name="query" placeholder="Enter your keyword">
              </form>
            </div>
          </div>

          <div class="widget">
            <h6 class="widget-title">Facebook Page</h6>
            <ul class="widget-body media-list">
<div class="fb-page" data-href="<?=$fbPage;?>" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><div class="fb-xfbml-parse-ignore"></div></div>
            </ul>
          </div>
        </div>