<?php
$i = 0;
foreach(array_slice($res, $start, 10, true) as $index => $item){
$title = $item->title;
$cleartitle = trim(preg_replace('/ +/', ' ', preg_replace('/[^A-Za-z0-9 ]/', ' ', urldecode(html_entity_decode(strip_tags($title))))));
$canonicaltitle = strtolower(str_replace(" ","-",$cleartitle));
$jobId = (string) $item->id; 
$jobId = substr($jobId, 1, -1);
$content=strip_tags($item->content);
$content= str_replace('Job Responsibility','',$content);
$content = str_replace('Job Benifits ','',$content);
$string = substr($content, 0, 300);
$content = substr($string, 0, strrpos($string, ' ')) . " ...";
$pubDate = $item->pubdate; 
$date = explode(' ',$pubDate);
$date = explode('/',$date[1]);
$date1 = $date[0];
$date2 = $date[1];
//$dateObj   = DateTime::createFromFormat('!m', $date2);
//$date2 = $dateObj->format('M');
$date2 = date('M', mktime(0, 0, 0, $date2, 10));
$contract = $item->contract;
$company = $item->company;
$scompany = substr($company, 0, 40);
$company = substr($scompany, 0, strrpos($scompany, ' ')) . " ";
$salary = $item->salary;
$salary = str_replace('Per Month','',$salary);

if($contract == "Full Time"){
$codeColor = "success";
} elseif($contract == "Part Time"){
$codeColor = "info";
} elseif($contract == "Full Time,Part Time"){
$codeColor = "danger";
} elseif($contract == "Internship"){
$codeColor = "warning";
}
?>
            <!-- Job item -->
            <div class="col-xs-12">

              <a class="item-block" href="<?=$canonicaltitle;?>-<?=$jobId;?>.html">
			<header>
<div class="date"><?=$date1;?> <span><?=$date2;?></span></div>
                  <div class="hgroup">
                    <h4><?=$item->title;?> <?php if($salary != "Undisclose"){ echo $salary;}?></h4>
                    <h5><?=$company;?></h5>
				
                  </div>
                  <div class="header-meta">
                    <span class="location small"><?=$item->region;?></span>
                    <span class="label label-<?=$codeColor;?>"><?=$item->contract;?></span>
                  </div>
                </header>
			<div class="item-body hidden-xs">
                  <p class="small"><?=$content;?></p>
                </div>
              </a>
            </div>
            <!-- END Job item -->
<?php
if($i == 4){
echo '<div class="col-xs-12 text-center"><p class="small"></p>';
echo $adsCenter;
echo "</div>";
}
$i++;
} 
?>