    <!-- Site footer -->
    <footer class="site-footer">

      <!-- Top section -->
      <div class="container">
        <div class="row">
          <div class="col-sm-12 col-md-3">
            <h6>About</h6>
            <p class="text-justify"><?=$footerDesc;?></p>
          </div>

          <div class="col-xs-6 col-md-3">
            <ul class="footer-links">
			<li><a href="lokasi-selangor.html" title="kerja kosong di selangor"><img src="assets/img/negeri/Selangor.png" alt="negeri selangor"> Selangor </a></li>
              <li><a href="lokasi-johor.html" title="kerja kosong di johor"><img src="assets/img/negeri/Johor.png" alt="negeri johor"> Johor </a></li>
											<li><a href="lokasi-kedah.html" title="kerja kosong di kedah"><img src="assets/img/negeri/Kedah.png" alt="negeri kedah"> Kedah </a></li>
											<li><a href="lokasi-kelantan.html" title="kerja kosong di kelantan"><img src="assets/img/negeri/Kelantan.png" alt="negeri kelantan"> Kelantan </a></li>
											<li><a href="lokasi-melaka.html" title="kerja kosong di melaka"><img src="assets/img/negeri/Melaka.png" alt="negeri melaka"> Melaka </a></li>
											
            </ul>
          </div>

          <div class="col-xs-6 col-md-3">
            <ul class="footer-links">
              <li><a href="lokasi-pahang.html" title="kerja kosong di pahang"><img src="assets/img/negeri/Pahang.png" alt="negeri pahang"> Pahang </a></li>
											<li><a href="lokasi-perak.html" title="kerja kosong di perak"><img src="assets/img/negeri/Perak.png" alt="negeri perak"> Perak </a></li>
											<li><a href="lokasi-perlis.html" title="kerja kosong di perlis"><img src="assets/img/negeri/Perlis.png" alt="negeri perlis"> Perlis </a></li>
											<li><a href="lokasi-penang.html" title="kerja kosong di penang"><img src="assets/img/negeri/Penang.png" alt="negeri pulau pinang"> Penang </a></li>
											<li><a href="lokasi-sabah.html" title="kerja kosong di sabah"><img src="assets/img/negeri/Sabah.png" alt="negeri sabah"> Sabah </a></li>
            </ul>
          </div>
		  
		  <div class="hidden-xs col-md-3">
            <ul class="footer-links">
             <li><a href="lokasi-sarawak.html" title="kerja kosong di sarawak"><img src="assets/img/negeri/Sarawak.png" alt="negeri sarawak"> Sarawak </a></li>
											<li><a href="lokasi-negeri-sembilan.html" title="kerja kosong di negeri sembilan"><img src="assets/img/negeri/Negeri_Sembilan.png" alt="negeri sembilan"> Negeri Sembilan </a></li>
											<li><a href="lokasi-terengganu.html" title="kerja kosong di terengganu"><img src="assets/img/negeri/Terengganu.png" alt="negeri terengganu"> Terengganu </a></li>
											<li><a href="lokasi-kuala-lumpur.html" title="kerja kosong di kuala lumpur"><img src="assets/img/negeri/Kuala_Lumpur.png" alt="negeri kuala lumpur"> Kuala Lumpur </a></li>
											<li><a href="lokasi-putrajaya.html" title="kerja kosong di putrajaya"><img src="assets/img/negeri/Putrajaya.png" alt="wilayah persekutuan putrajaya"> Putrajaya </a></li>
            </ul>
          </div>
        </div>

        <hr>
      </div>
      <!-- END Top section -->

      <!-- Bottom section -->
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-6 col-xs-12">
            <p class="copyright-text">Copyrights &copy; <?=date('Y');?> <?=$webTitle;?> All Rights Reserved.</p>
          </div>

          <div class="col-md-4 col-sm-6 col-xs-12">
            <ul class="social-icons">
              <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
              <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
              <li><a class="dribbble" href="#"><i class="fa fa-dribbble"></i></a></li>
              <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
              <li><a class="instagram" href="#"><i class="fa fa-instagram"></i></a></li>
            </ul>
          </div>
        </div>
      </div>
      <!-- END Bottom section -->

    </footer>
    <!-- END Site footer -->


    <!-- Back to top button -->
    <a id="scroll-up" href="#"><i class="ti-angle-up"></i></a>
    <!-- END Back to top button -->

    <!-- Scripts -->
    <script src="assets/js/app.min.js"></script>
    <script src="assets/js/custom.js"></script>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=<?=$addThis;?>"></script> 
<script>

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', '<?=$analyticsId;?>']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>
  </body>
</html>