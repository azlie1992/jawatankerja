<?php
function extstr3($content,$start,$end){
  if($content && $start && $end) {
    $r = explode($start, $content);
    if (isset($r[1])){
        $r = explode($end, $r[1]);
        return $r[0];
    }
    return '';
  }
}

$xml = "jobxml2.xml";
$simpleXMLobject = file_get_contents($xml);
$first = '<?xml version="1.0" encoding="utf-8"?><adhance><job>';
$last = '</job></adhance>';
$read = $first.extstr3($simpleXMLobject,$first,$last).$last;
file_put_contents($xml, $read);

rename('jobxml.xml', 'oldjob.xml');
rename('jobxml2.xml','jobxml.xml');
?>